---
name: Bug report
about: Create a bug report
title: ''
labels: ''
assignees: ''

---

<!-- Please provide this information if relevant -->
* Monitor manufacturer and model number:
* Input source (HDMI, VGA, display port, ect.):
* Output device (video card, discrete graphics, ect.):
* Operating system:
* Python version:
* monitorcontrol version (`monitorcontrol --version`):

# Steps to Reproduce

<!-- Add information on how to reproduce this bug -->
