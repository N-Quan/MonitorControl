Command Line Interface
######################

.. note::

    The command line interface is very limited in functionality, and it will
    change in the next major version.

This message can be found with ``monitorcontrol --help``.

.. literalinclude:: cli.txt
   :language: text
