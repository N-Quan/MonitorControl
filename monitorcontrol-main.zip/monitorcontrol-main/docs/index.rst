.. include:: ../README.rst

.. toctree::
   :maxdepth: 2
   :caption: Contents

   api
   cli
   issues
   license
   linux_setup
   references


Indices and Tables
##################
* :ref:`genindex`
* :ref:`modindex`
