Known Issues
############

-  Will not work on Windows if you have more than one physical monitor
   per handle.  This typically occurs if you are using NVIDIA surround or AMD
   eyefinity.  This should work in most cases for multi-monitor setups.
-  Limited MCCS commands implemented, only back-light and power modes
   are available. Please open an issue or pull request if you would like
   additional controls.
-  No support for Mac.
