References
##########

-  VESA Monitor Control Command Set Standard Version 2.2a
-  Display Data Channel Command Interface Standard Version 1.1
-  `Informatic/python-ddcci <https://github.com/Informatic/python-ddcci>`__
-  `siemer/ddcci <https://github.com/siemer/ddcci/>`__
-  https://stackoverflow.com/a/18065609
